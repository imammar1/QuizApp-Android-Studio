package com.example.finalproject4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EndActivity extends AppCompatActivity {
    private TextView finalScoreTextView;
    private Button restartButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end);

        int score = getIntent().getIntExtra("finalScore", 0);

        finalScoreTextView = findViewById(R.id.text_view_final_score);
        finalScoreTextView.setText("Correct: " + score + "/5");

        restartButton = findViewById(R.id.button_restart);
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EndActivity.this, QuizActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}

